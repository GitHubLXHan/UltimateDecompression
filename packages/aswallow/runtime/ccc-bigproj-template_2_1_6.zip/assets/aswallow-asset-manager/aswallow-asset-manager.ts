import { DragonBonesAssetParser, DragonBonesAtlasAssetParser } from "./dragonbone-asset-parser";
import { isMiniGame } from "./minigame-utils";
import { PlistAssetParser } from "./plist-asset-parser";
import { SpineAssetParser } from "./spine-asset-parser";
import { TiledMapAssetParser } from "./tiled-map-asset-parser";
if (!window.aswallow) {
    window.aswallow = {} as any;
}
/**
 * 预览子项目bundle加载协议
 */
export const PREVIEW_BUNDLE_LOAD_PROTOCOL = "preview_load_bundle";
/**获取主项目bundle名json */
export const PREVIEW_GET_MAIN_PROJ_BUNDLENAMES = "aswallow/preview/main_proj_bundleNames.json";
aswallow.isMiniGame = isMiniGame
export class AwExtAssetManager implements aswallow.IExtAssetManager {


    private _extResVerPathMap: { [key: string]: string } = {};
    // private _extAssetMap: { [key: string]: cc.Asset } = {};
    private _handlerMap: { [key: string]: aswallow.IAssetParser } = {};
    private _inited: boolean;
    private _previewMainBundleNames: string[];
    private _bundleBaseDir: string;
    private _initing: boolean;
    constructor() {
        this.registAssetParser(new DragonBonesAssetParser());
        this.registAssetParser(new DragonBonesAtlasAssetParser());
        this.registAssetParser(new PlistAssetParser());
        this.registAssetParser(new SpineAssetParser());
        this.registAssetParser(new TiledMapAssetParser());
    }
    /**
    * 原生可读写目录路径，比如 /dara/data/some/path/to/
    * 远程服务器路径，比如 https://www.xxxx.com/
    * 原生JSB 默认jsb.fileUtils.getDefaultResourceRootPath()
    * 模拟器 默认 window["deviceDataPath"];
    * web 默认 ""
    */
    private _extResRoot: string;


    public get extResRoot(): string {
        return this._extResRoot;
    }
    public set extResRoot(root: string) {
        if (root === undefined || root === null) return;
        this._extResRoot = root;
    }
    /**
     * 外部bundle根路径
     * 可以是原生路径
     * 也可以是远程服务器路径
     * 原生的话，根路径默认 jsb.fileUtils.getDefaultResourceRootPath()
     * 模拟器 默认 window["deviceDataPath"];
     * web 默认 window.location.herf
     */
    private _extBundleRoot: string
    public get extBundleRoot(): string {
        return this._extBundleRoot;
    }
    public set extBundleRoot(value: string) {
        if (value === undefined || value === null) return;
        this._extBundleRoot = value;
    }
    /**
     * 根文件夹名,默认ext-res
     */
    public _baseDir: string;

    public set baseDir(dirName: string) {
        if (dirName === undefined || dirName === null) return;
        this._baseDir = dirName;
    }
    public get baseDir(): string {
        return this._baseDir;
    }

    public async init(aswallowConfig?: import("aswallow").IAswallowConfig): Promise<void> {

        if (this._initing || this._inited) return;
        this._initing = true;
        if (!aswallowConfig) {
            await new Promise<void>((res) => {

                cc.resources.load("aswallow-config", cc.JsonAsset, (err, asset: cc.JsonAsset) => {
                    if (!err) {
                        aswallowConfig = asset.json;
                    } else {
                        aswallowConfig = {} as any;
                        console.error(`[ASWALLOW] 加载失败`, err);
                    }

                    res();
                });
            })
        }


        let { miniGameRoot, extResRoot, externalResPath } = aswallowConfig;


        //小游戏
        if (aswallow.isMiniGame()) {
            const serverUrl = miniGameRoot ? miniGameRoot : cc.assetManager.downloader.remoteServerAddress;
            //@ts-ignore
            this.extResRoot = cc.path.join(`${serverUrl}`, "remote");
        }
        //模拟器和原生处理
        if (window["CC_SIMULATOR"]) {
            this._extResRoot = window["deviceDataPath"];
            this._extBundleRoot = aswallowConfig.simulateExtBundleRoot ? aswallowConfig.simulateExtBundleRoot : "http://localhost:7456";
        } else if (CC_JSB) {
            if (!aswallowConfig.nativeExtResIsRemote) {
                this._extResRoot = "assets";
            } else {
                //@ts-ignore
                this._extResRoot = extResRoot ? extResRoot : cc.path.join(cc.assetManager.downloader.remoteServerAddress, "remote");
            }

        }

        //WEB 处理
        if (!this._extResRoot) {
            this._extResRoot = extResRoot ? extResRoot : "";
        }
        if (!this._extBundleRoot) {
            this._extBundleRoot = window.location.origin + window.location.pathname;
        }
        if (CC_PREVIEW || window["CC_SIMULATOR"]) {
            let mainBundleNamesJsonUrl;
            if (this._extBundleRoot) {
                //@ts-ignore
                mainBundleNamesJsonUrl = cc.path.join(this._extBundleRoot, `${PREVIEW_GET_MAIN_PROJ_BUNDLENAMES}`);
            }

            await new Promise<void>((res) => {
                cc.assetManager.loadRemote(mainBundleNamesJsonUrl, (err, asset: cc.JsonAsset) => {
                    if (!err) {
                        this._previewMainBundleNames = asset.json;
                    }
                    console.log(`主项目bundle名数组`, this._previewMainBundleNames);
                    res();
                })
            })
        }
        if (!this._baseDir || this._baseDir.trim() === "") {
            this._baseDir = externalResPath ? externalResPath : "ext-res";
        }
        // if (!this._bundleBaseDir || this._bundleBaseDir.trim() === "") {
        //     this._bundleBaseDir = extBundleDir ? extBundleDir : "ext-bundles";
        // }
        let versionFilePath: string = "version.json";
        if (CC_JSB) {
            versionFilePath = this._transformUrl({ url: versionFilePath });

        } else {
            const time = (new Date()).getTime();
            versionFilePath = this._transformUrl({ url: `${versionFilePath}?t=${time}` });
        }
        // console.log(`加载versionFile：${versionFilePath}`);
        await new Promise<void>((res) => {
            cc.assetManager.loadRemote(versionFilePath, { maxRetryCount: 2 }, (err, item: cc.JsonAsset) => {
                if (err) {
                    this._extResVerPathMap = {};
                } else {
                    this._extResVerPathMap = item.json;
                }
                res();
            })
        })
        this._initing = false;
        this._inited = true;

    }

    public registAssetParser(handler: aswallow.IAssetParser) {
        const handlerMap = this._handlerMap;
        if (!handler || !handler.type || handlerMap[handler.type]) {
            console.warn(`[ext-loader]解析处理器注册失败:: type:${handler ? handler.type : undefined}${handlerMap[handler.type] && (",处理器已经存在")}`);
            return;
        }
        handler.extAssetMgr = this;
        handler.onRegist && handler.onRegist();
        this._handlerMap[handler.type] = handler;
    }
    /**
     * 加载并解析外部资源
     * @param paths 
     * @param onComplete 
     * @param onProgress 
     * @param type 
     */
    public load(resReqItems: aswallow.ResRequestItem | aswallow.ResRequestItem[], onComplete?: (error: Error, result: aswallow.LoadResult) => void, onProgress?: (finish: number, total: number, item: any) => void): void {
        resReqItems = this._resolveVerUrls(resReqItems);
        const len = resReqItems.length;
        let handler: aswallow.IAssetParser;
        const handlerMap = this._handlerMap;
        let resReqItem: aswallow.IResRequestItem;
        this.ccload(resReqItems as aswallow.IResRequestItem[], (err, items) => {
            let res: aswallow.LoadResult;
            if (!err) {
                let asset: any;
                const assetMap: { [key: string]: any } = {};
                let path: string;
                for (let i = 0; i < len; i++) {
                    resReqItem = resReqItems[i];
                    path = resReqItem.extResPath;
                    asset = this.get(path);
                    if (resReqItem.assetType && !asset["__extParsed"]) {

                        handler = resReqItem.assetType ? handlerMap[resReqItem.assetType] : undefined;
                        if (handler) {
                            asset = handler.parse(resReqItem.extResPath, asset);
                        }
                        asset["__extParsed"] = true;
                    }
                    if (asset) {
                        assetMap[resReqItem.extResPath] = asset;
                    }
                }
                const values = Object.values(assetMap)
                if (values.length > 1) {
                    res = {
                        isCompleted: true,
                        map: assetMap
                    }
                } else {
                    res = values[0];
                }
            }
            onComplete && onComplete(err, res);
        }, onProgress);

    }
    public get<T extends cc.Asset = any>(path: string | aswallow.IResRequestItem): T[] | T {
        if (typeof path === "string") {
            return cc.assetManager.assets.get(path) as any;
        } else {
            const reqItems = this._resolveVerUrls(path);
            const assets: T[] = [];
            for (let i = 0; i < reqItems.length; i++) {
                assets.push(cc.assetManager.assets.get(reqItems[i].extResPath) as T);
            }
            return assets;
        }

    }

    /**
     * 缓存资源
     * @param extAssetPath 
     * @param asset 
     */
    public cache(extAssetPath: string, asset: any): void {
        asset["__extAssetPath"] = extAssetPath;
        cc.assetManager.assets.add(extAssetPath, asset);
    }
    public unCache(key: string): void {
        cc.assetManager.assets.remove(key);
    }
    public release(resReqItems: aswallow.ResRequestItem | aswallow.ResRequestItem[]): void {
        resReqItems = this._resolveVerUrls(resReqItems);
        let asset: cc.Asset;
        let reqItem: aswallow.IResRequestItem;
        for (let i = 0; i < resReqItems.length; i++) {
            reqItem = resReqItems[i] as aswallow.IResRequestItem;
            asset = this.get(reqItem.extResPath) as cc.Asset;
            if (asset) {
                this.unCache(reqItem.extResPath);
                asset.destroy();
            }
        }

    }
    public releaseAsset(asset: cc.Asset) {
        if (asset["__extAssetPath"]) {
            this.release(asset["__extAssetPath"]);
        } else {
            cc.assetManager.releaseAsset(asset);
        }
    }
    /**
     * 加载外部资源，不做解析
     * @param requestItems 
     * @param onComplete 
     * @param onProgress 
     */
    public ccload(requestItems: aswallow.IResRequestItem | aswallow.IResRequestItem[],
        onComplete?: (error: Error, result: any) => void,
        onProgress?: (finish: number, total: number, item: any) => void) {
        const options = { preset: "remote", __isNative__: true };
        const loadedMap = {};
        let loadedCount = 0;
        requestItems = Array.isArray(requestItems) ? requestItems : [requestItems];
        const needLoadRequestItems = [];
        for (let i = requestItems.length - 1; i >= 0; i--) {
            const path = requestItems[i].extResPath;
            const asset = this.get(path);
            if (asset) {
                loadedCount++;

                loadedMap[path] = asset;
            } else {
                needLoadRequestItems.push(requestItems[i])
            }
        }
        let res: aswallow.LoadResult;
        if (!needLoadRequestItems.length) {
            if (loadedCount > 1) {
                res = {
                    isCompleted: true,
                    map: loadedMap
                };
            } else {
                res = Object.values(loadedMap)[0] as any;
            }
            onComplete && onComplete(undefined, res);
        } else {
            cc.assetManager.loadAny(needLoadRequestItems, options, (function (finish, total, item) {
                loadedMap[item.url] = item.content;
                onProgress && onProgress(finish, total, item);
            }), ((err, _native) => {
                if (!err) {
                    let asset: cc.Asset;
                    let content;
                    let reqItem: aswallow.IResRequestItem;
                    const factory = cc.assetManager.factory;
                    let ext: string;
                    for (let i = 0; i < needLoadRequestItems.length; i++) {
                        reqItem = needLoadRequestItems[i];
                        content = loadedMap[reqItem.url];
                        asset = this.get(reqItem.extResPath) as cc.Asset;
                        if (!asset) {
                            ext = reqItem.ext || cc.path.extname(reqItem.url);
                            factory.create(reqItem.url, content, ext, null, (err, out) => {
                                if (!err) {
                                    out._native = ext;
                                    asset = out;
                                }
                            });
                            if (reqItem.assetType) if (!asset["__extParsed"]) asset["__extParsed"] = false;
                            this.unCache(reqItem.url);
                            delete loadedMap[reqItem.url];

                            this.cache(reqItem.extResPath, asset);
                        }
                        loadedMap[reqItem.extResPath] = asset;
                    }
                    const assets = Object.values(loadedMap)
                    if (assets.length > 1) {
                        res = {
                            isCompleted: true,
                            map: loadedMap
                        }
                    } else {
                        res = assets[0] as any;
                    }

                }
                onComplete && onComplete(err, res);
            }));
        }
    }
    /**
     * 加载远程bundle
     * @param bundleName 
     * @param onComplete 
     * @param isLocal 是否本地bundle
     */
    public loadBundle(bundleName: string, onComplete: (err: Error, bundle?: cc.AssetManager.Bundle) => void) {
        console.log("加载bundle", `${bundleName}`)
        if (CC_PREVIEW && !this._previewMainBundleNames.includes(bundleName)) {
            // cc.assetManager.loadBundle(bundlePath, { version: bundleVer, isAswallowBundle: true }, onComplete);
            let bundlePath = `${PREVIEW_BUNDLE_LOAD_PROTOCOL}/${bundleName}`;
            //@ts-ignore
            bundlePath = cc.path.join(this._extBundleRoot, bundlePath)

            cc.assetManager.loadBundle(bundlePath, onComplete);

        } else {
            cc.assetManager.loadBundle(bundleName, onComplete);
        }
    }
    /**
     * 拼接最终url和根据version.json转换实际资源url
     * @param reqItem 
     * @returns 
     */
    private _transformUrl(reqItem: aswallow.IResRequestItem): string {
        let url = reqItem.url;
        if (this._extResVerPathMap[url]) {
            url = this._extResVerPathMap[url];
        }
        // @ts-ignore
        url = cc.path.join(reqItem.root ? reqItem.root : this.extResRoot, reqItem.baseDir ? reqItem.baseDir : this._baseDir, url);
        return url;
    }
    /**
     * 拼接bundle资源路径
     * @param path 
     * @returns 
     */
    private _transformBundlePath(path: string): string {
        let root = this._extBundleRoot;
        // @ts-ignore
        path = cc.path.join(root, this._bundleBaseDir, path);
        return path;
    }
    /**
     * 获取bundle版本
     * @param bundlePath 
     * @returns 
     */
    private _getBundleVersion(bundlePath: string): string {
        if (this._previewMainBundleNames) {
            return this._previewMainBundleNames[bundlePath];
        }

    }
    private _resolveVerUrls(resReqItems: aswallow.ResRequestItem | aswallow.ResRequestItem[]): aswallow.IResRequestItem[] {
        resReqItems = Array.isArray(resReqItems) ? resReqItems : [resReqItems];
        let resReqItem: aswallow.ResRequestItem;
        let handler: aswallow.IAssetParser;
        const handlerMap = this._handlerMap;
        let resultReqs: aswallow.ResRequestItem[] = [];
        for (let i = resReqItems.length - 1; i >= 0; i--) {
            resReqItem = resReqItems[i];
            if (typeof resReqItem === "string") {
                resReqItem = { url: resReqItem };
                resultReqs.push(resReqItem);
            } else if (cc.path.extname(resReqItem.url) === "") {
                handler = resReqItem.assetType ? handlerMap[resReqItem.assetType] : undefined;
                if (handler) {
                    const deps = handler.getDepReqs ? handler.getDepReqs(resReqItem) : undefined
                    if (deps) {
                        resultReqs = (resultReqs as aswallow.ResRequestItem[]).concat(deps);

                    } else {
                        console.warn(`路径没后缀，获取引用为空:${resReqItem.url}`);
                    }

                } else {
                    console.warn(`路径没后缀，又没处理器获取引用:${resReqItem.url}`);
                }

                //移除
                // resReqItems[i] = resReqItems[resReqItems.length - 1];
                // resReqItems[resReqItems.length - 1] = resReqItem;
                // resReqItems.pop();
            } else {
                resultReqs.push(Object.assign({}, resReqItem));
            }
            const depUrls = resReqItem.deps;
            if (depUrls) {

                for (let k = 0; k < depUrls.length; k++) {
                    resReqItem = { url: depUrls[k] };
                    resultReqs.push(resReqItem);
                }
            }

        }
        resReqItems.length = 0;
        //处理路径
        for (let i = 0; i < resultReqs.length; i++) {
            resReqItem = resultReqs[i] as aswallow.IResRequestItem;
            resReqItem.extResPath = resReqItem.url;
            resReqItem.url = this._transformUrl(resReqItem);
        }

        return resultReqs as aswallow.IResRequestItem[];
    }

}

aswallow.extAssetMgr = new AwExtAssetManager();