const miniGamePlatforms = [
    cc.sys.WECHAT_GAME,
    cc.sys.ALIPAY_GAME,
    cc.sys.QTT_GAME,//趣头条
    cc.sys.BYTEDANCE_GAME,
    cc.sys.HUAWEI_GAME,
    cc.sys.OPPO_GAME,
    cc.sys.VIVO_GAME,
    cc.sys.XIAOMI_GAME,
    cc.sys.BAIDU_GAME,
    cc.sys.JKW_GAME,//CocosPlay
    cc.sys.LINKSURE//连尚小游戏
];
/**判断是否为小游戏环境 */
export function isMiniGame() {
    return miniGamePlatforms.includes(cc.sys.platform)
}