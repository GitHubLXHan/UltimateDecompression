const downloadJson = cc.assetManager.downloader["_downloaders"][".json"];
const downloadScript = cc.assetManager.downloader["downloadScript"];
const REMOTE_SERVER_ROOT = cc.assetManager.downloader["_remoteServerAddress"];
const downloader = cc.assetManager.downloader;
import * as miniGameUtils from "./minigame-utils";
const getUserDataPath = function getUserDataPath() {
    return jsb.fileUtils.getWritablePath().replace(/[\/\\]*$/, '');
}
var REGEX = /^\w+:\/\/.*/;
// if (CC_JSB) {
//     const remoteBundles = window["remoteBundles"];
//     const cacheManager = cc.assetManager.cacheManager as any;
//     const jsbDownloadBundle = function (nameOrUrl, options, onComplete) {
//         var bundleName = cc.path.basename(nameOrUrl);
//         var version = options.version || cc.assetManager.downloader["bundleVers"][bundleName];
//         var url;
//         if (options.isAswallowBundle) {
//             url = nameOrUrl;
//         } else {
//             if (REGEX.test(nameOrUrl) || nameOrUrl.startsWith(getUserDataPath())) {
//                 url = nameOrUrl;
//                 cacheManager.makeBundleFolder(bundleName);
//             } else {
//                 if (remoteBundles && remoteBundles[bundleName]) {
//                     url = "".concat(REMOTE_SERVER_ROOT, "remote/").concat(bundleName);
//                     cacheManager.makeBundleFolder(bundleName);
//                 } else {
//                     console.log("bundleName", bundleName)
//                     url = "assets/".concat(bundleName);
//                 }
//             }
//         }


//         var config = "".concat(url, "/config.").concat(version ? version + '.' : '', "json");
//         options.__cacheBundleRoot__ = bundleName;
//         downloadJson(config, options, function (err, response) {
//             if (err) {
//                 return onComplete(err, null);
//             }

//             var out = response;
//             out && (out.base = url + '/');
//             var js = "".concat(url, "/index.").concat(version ? version + '.' : '').concat(out.encrypted ? 'jsc' : "js");
//             downloadScript(js, options, function (err) {
//                 if (err) {
//                     return onComplete(err, null);
//                 }

//                 onComplete(err, out);
//             });
//         });
//     }
//     cc.assetManager.downloader.register("bundle", jsbDownloadBundle);
// }

