// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html


const { ccclass, property } = cc._decorator;


@ccclass
export default class Main extends cc.Component {

    // LIFE-CYCLE CALLBACKS:

    async onLoad() {
        // await aswallow.extAssetMgr.init();

        // await aswallow.extAssetMgr.init({
        //     extBundleDir: "ext-bundles",
        //     defaultBuildPath: "build-ext-res",
        //     externalResPath: "ext-res",
        //     extResRoot: "http://localhost:8090"
        // })
        // console.log("可读写路径");
        // console.log(jsb&&jsb.fileUtils.getWritablePath());
        // console.log("默认资源路径");
        // console.log(jsb&&jsb.fileUtils.getDefaultResourceRootPath());
        // console.log("")
    }

    start() {

    }

    // update (dt) {}
}
