// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

import { AwExtAssetManager } from "../../aswallow-asset-manager/aswallow-asset-manager";
import { parsePlist } from "../../aswallow-asset-manager/plist-asset-parser";

const { ccclass, property } = cc._decorator;

@ccclass
export default class LoadAtlas extends cc.Component {
    @property(cc.Sprite)
    emojiSp: cc.Sprite = undefined;
    emojiAtlasUrlInfo: aswallow.IResRequestItem;
    private _isLoading: boolean;
    async start() {
        this.loadAtlas();
    }
    async loadAtlas() {
        if (this._isLoading) return;
        this._isLoading = true;
        await aswallow.extAssetMgr.init();

        //依赖解析
        this.emojiAtlasUrlInfo = { url: "atlas/emoji", assetType: "plist" } as aswallow.IResRequestItem;
        aswallow.extAssetMgr.load([this.emojiAtlasUrlInfo], (err, result) => {
            console.log(result);
            const [emojiAtlas] = aswallow.extAssetMgr.get(this.emojiAtlasUrlInfo);

            console.log(emojiAtlas);
            this.emojiSp.spriteFrame = emojiAtlas.getSpriteFrame("emoji2")
            this._isLoading = false;
        });
    }
    onDestroy() {
        this.releaseAtlas();
    }
    releaseAtlas() {
        this.emojiSp.spriteFrame = null;
        const [emojiAtlas] = aswallow.extAssetMgr.get(this.emojiAtlasUrlInfo);
        (emojiAtlas as cc.SpriteAtlas).destroy();
        aswallow.extAssetMgr.release(this.emojiAtlasUrlInfo);
    }


    // update (dt) {}
}
