// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

import { AwExtAssetManager } from "../../aswallow-asset-manager/aswallow-asset-manager";

const { ccclass, property } = cc._decorator;

@ccclass
export default class LoadSpines extends cc.Component {


    @property(sp.Skeleton)
    spine_bin: sp.Skeleton = undefined;
    @property(sp.Skeleton)
    spine_json: sp.Skeleton = undefined;
    spineBoyResUrlInfo: aswallow.IResRequestItem;
    spineBoyAtlasUrl: string;
    spineBoyTexUrl: string;
    raptorProResUrlInfo: aswallow.IResRequestItem;
    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    async start() {
        const extAssetMgr = aswallow.extAssetMgr;
        await extAssetMgr.init();
        this.spineBoyResUrlInfo = { url: "spines/spineboy/spineboy.json", assetType: "SpineAsset" };
        this.spineBoyAtlasUrl = "spines/spineboy/spineboy.txt";
        this.spineBoyTexUrl = "spines/spineboy/spineboy.png";
        extAssetMgr.load([this.spineBoyResUrlInfo, this.spineBoyAtlasUrl, this.spineBoyTexUrl],
            (err, items) => {
                console.log(items)
                this.spine_json.skeletonData = extAssetMgr.get(this.spineBoyResUrlInfo.url) as any;
                this.spine_json.animation = 'run';
            });
        //加载二进制,依赖解析式加载
        this.raptorProResUrlInfo = { url: "spines/spineRatorBin/raptor-pro", assetType: "SpineAsset", ext: "skel" };
        extAssetMgr.load([this.raptorProResUrlInfo], (err, items) => {
            console.log(items)
            const [raptorProSkeletonData] = extAssetMgr.get(this.raptorProResUrlInfo);
            this.spine_bin.skeletonData = raptorProSkeletonData;
            this.spine_bin.animation = 'walk';
            // this.spine._updateSkeletonData
        });
    }
    onDestroy() {
        this.releaseSpines();
    }
    releaseSpines() {
        aswallow.extAssetMgr.release([
            this.spineBoyResUrlInfo,
            this.spineBoyAtlasUrl,
            this.spineBoyTexUrl,
            this.raptorProResUrlInfo])
    }
    // update (dt) {}
}
