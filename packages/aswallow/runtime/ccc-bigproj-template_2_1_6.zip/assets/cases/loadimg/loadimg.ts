// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

import { AwExtAssetManager } from "../../aswallow-asset-manager/aswallow-asset-manager";


const { ccclass, property } = cc._decorator;

@ccclass
export default class LoadImg extends cc.Component {

    @property(cc.Sprite)
    sp: cc.Sprite = null;

    @property
    text: string = 'hello';
    private _extLoader: AwExtAssetManager;
    private _scheduleCallback: () => void;

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}
    async onLoad() {

        // await extLoader.initVersion();
        // cc.assetManager.loadBundle("testbundle", () => {
        //     console.log("加载完成")
        // })
    }
    async start() {
        await aswallow.extAssetMgr.init();
        cc.log("加载散图")
        console.log(`加载外部资源${"fgui-res/i0.png"}`);
        this.loadRes();
    }
    loadRes() {
        let asset: cc.Asset;
        let index = 0;
        this._scheduleCallback = () => {
            asset = aswallow.extAssetMgr.get(`${iconRoot}/i${index}.png`);
            index = Math.floor(Math.random() * 10);
            this.sp.spriteFrame = null;
            if (asset) {
                this.sp.spriteFrame = new cc.SpriteFrame(asset as cc.Texture2D);
            }

        }
        let iconRoot = "fgui-res/Icons";
        let resPaths = [];
        for (let i = 0; i < 10; i++) {
            resPaths.push(iconRoot + "/i" + i + ".png");
        }
        // cc.assetManager.preloadAny()
        console.log(`加载散图资源`, resPaths);
        aswallow.extAssetMgr.load(resPaths, (err, result: aswallow.ILoadResult) => {
            if (!err) {
                console.log(`加载成功`)
                console.log(result);

                this.schedule(this._scheduleCallback, 1, cc.macro.REPEAT_FOREVER);


                // this.sp.spriteFrame.ensureLoadTexture();

            }

        });
        // //逐个加载
        // cc.assetManager.downloader.maxRequestsPerFrame = 10;
        // for (let i = 0; i < 10; i++) {
        //     let url = "http://localhost:7456/ext-res/" + iconRoot + "/i" + i + ".png";
        //     const index = i;
        //     cc.assetManager.loadRemote(url, () => {
        //         console.log(`url:${url},index:${index}`);
        //     })
        //     // aswallow.extAssetMgr.load(url, (err, result) => {
        //     //     console.log(`url:${url},index:${index}`);
        //     // })
        // }
    }
    releaseImgs() {
        this.unschedule(this._scheduleCallback);
        aswallow.extAssetMgr.release(["fgui-res/i0.png", "fgui-res/i1.png"]);
    }
    // update (dt) {}
}
