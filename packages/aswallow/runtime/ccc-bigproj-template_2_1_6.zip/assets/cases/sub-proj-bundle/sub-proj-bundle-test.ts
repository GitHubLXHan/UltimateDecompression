// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

const { ccclass, property } = cc._decorator;

@ccclass
export default class SubProjBundleTest extends cc.Component {

    @property(cc.Node)
    mainBundle: cc.Node = null;

    @property(cc.Node)
    mainRemoteBundle: cc.Node = null;

    @property(cc.Node)
    subProjBundle: cc.Node = null;

    @property(cc.Node)
    subProjRemoteBundle: cc.Node = null;

    @property(cc.Node)
    subProjBundleRefTest: cc.Node = null;
    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    async start() {
        await aswallow.extAssetMgr.init();
        aswallow.extAssetMgr.loadBundle("main-res-bundle", (err, bundle) => {
            if (!err) {
                bundle.load("BuleMonster", cc.Prefab, (err, asset: cc.Prefab) => {
                    const node = cc.instantiate(asset) as unknown as cc.Node;
                    this.mainBundle.addChild(node);
                    node.x = node.y = 0;
                })
            }
        })
        aswallow.extAssetMgr.loadBundle("main-remote-bundle-test", (err, bundle) => {
            if (!err) {
                bundle.load("BuleMonster", cc.Prefab, (err, asset: cc.Prefab) => {
                    const node = cc.instantiate(asset) as unknown as cc.Node;
                    this.mainRemoteBundle.addChild(node);
                    node.x = node.y = 0;
                })
            }
        })
        aswallow.extAssetMgr.loadBundle("testbundle",
            (err, bundle) => {

                console.log(`加载testbundle`);
                console.log(err, bundle);
                if (err) {
                    return
                }
                bundle.load("prefabs/testprefab", cc.Prefab, (err, asset) => {
                    console.log(err, asset);
                    const node = cc.instantiate(asset) as unknown as cc.Node;
                    this.subProjBundle.addChild(node);
                    node.x = node.y = 0;
                })
            });
        aswallow.extAssetMgr.loadBundle("remote-bunlde-test",
            (err, bundle) => {

                console.log(`加载remote-bunlde-test`);
                console.log(err, bundle);
                if (err) {
                    return
                }
                bundle.load("YellowMonster", cc.Prefab, (err, asset) => {
                    console.log(err, asset);
                    const node = cc.instantiate(asset) as unknown as cc.Node;
                    this.subProjRemoteBundle.addChild(node);
                    node.x = node.y = 0;
                })
            });
        //加载引用了别的bundle资源的bundle的prefab
        aswallow.extAssetMgr.loadBundle("ref-other-bundle-res", async (err, bundle) => {
            console.log(`加载ref-other-bundle-res`);
            console.log(err, bundle);
            if (err) {
                return
            }
            if (bundle.deps && bundle.deps.length > 0) {
                let notLoadBundles = [];
                for (let i = 0; i < bundle.deps.length; i++) {
                    let depBundle = cc.assetManager.getBundle(bundle.deps[i]);
                    if (!depBundle) {
                        notLoadBundles.push(bundle.deps[i]);
                    }
                }
                let loadSuccess = !(notLoadBundles.length > 0);
                if (notLoadBundles.length > 0) {
                    loadSuccess = await new Promise<boolean>((res) => {
                        let loadEndCount = 0;
                        let hasError: boolean;
                        for (let i = 0; i < notLoadBundles.length; i++) {
                            aswallow.extAssetMgr.loadBundle(notLoadBundles[i], (err) => {
                                if (err) {
                                    hasError = true;
                                    console.error(err);
                                }
                                loadEndCount++;
                                if (loadEndCount >= notLoadBundles.length) {
                                    res(!hasError);
                                }
                            })
                        }
                    })
                }
                if (!loadSuccess) {
                    console.error(`加载失败`);
                    return;
                }
            }

            bundle.load("ref-testbundle-res", cc.Prefab, (err, asset) => {
                console.log(err, asset);
                const node = cc.instantiate(asset) as unknown as cc.Node;
                this.subProjBundleRefTest.addChild(node);
                node.x = node.y = 0;
            })

        })
    }

    // update (dt) {}
}
