// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

import { AwExtAssetManager } from "../../aswallow-asset-manager/aswallow-asset-manager";

const { ccclass, property } = cc._decorator;

@ccclass
export default class LoadTileMap extends cc.Component {

    @property(cc.TiledMap)
    tilemap: cc.TiledMap = null;

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}
    private _isLoaded: boolean;
    private _tmxAssets: string[] = ["imported/map.tmx", "imported/perspective_walls.tmx"];
    async start() {

        const extAssetMgr = aswallow.extAssetMgr;
        await extAssetMgr.init();
        let count = 0;
        const onLoaded = () => {
            count++;
            if (count >= 2) {
                this._isLoaded = true;
                this.tilemap.tmxAsset = extAssetMgr.get("imported/map.tmx");

            }
        }
        extAssetMgr.load({ url: "imported/map.tmx", deps: ["imported/barriers.png", "imported/ground.png"], assetType: "TiledMapAsset" }, onLoaded);
        //with tsx
        extAssetMgr.load({ url: "imported/perspective_walls.tmx", deps: ["imported/perspective_walls.png", "imported/perspective_walls.tsx"], assetType: "TiledMapAsset" }, onLoaded);
    }
    private _curAssetIndex: number = 0;
    switchTiledMapShow() {
        if (!this._isLoaded) return;
        this._curAssetIndex++;
        this._curAssetIndex = this._curAssetIndex % this._tmxAssets.length;

        this.tilemap.tmxAsset = aswallow.extAssetMgr.get(this._tmxAssets[this._curAssetIndex]);
    }
    // update (dt) {}
}
