// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

import { AwExtAssetManager } from "../../aswallow-asset-manager/aswallow-asset-manager";

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {
    @property(dragonBones.ArmatureDisplay)
    dragonBone_bin: dragonBones.ArmatureDisplay = undefined;
    @property(dragonBones.ArmatureDisplay)
    dragonBone_json: dragonBones.ArmatureDisplay = undefined;
    newDragonTestUrlInfo: aswallow.IResRequestItem;
    newDragonTestAtlasResUrlInfo: aswallow.IResRequestItem;
    newDragonTestTexUrl: string;
    swordsManUrlInfo: aswallow.IResRequestItem;
    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    async start() {

        const extAssetMgr = aswallow.extAssetMgr;
        await extAssetMgr.init()
        this.newDragonTestUrlInfo = { url: "dragonbones/dragon/NewDragonTest.json", assetType: "DragonBonesAsset" };
        this.newDragonTestAtlasResUrlInfo = { url: "dragonbones/dragon/texture.json", assetType: "DragonBonesAtlasAsset" };
        this.newDragonTestTexUrl = "dragonbones/dragon/texture.png";
        extAssetMgr.load([this.newDragonTestAtlasResUrlInfo, this.newDragonTestUrlInfo,
        this.newDragonTestTexUrl], (err, items) => {
            console.log(items);
            const newDragonTestAsset = extAssetMgr.get(this.newDragonTestUrlInfo.url);
            const newDragonTestAtlasAsset = extAssetMgr.get("dragonbones/dragon/texture.json");
            this.dragonBone_json.dragonAsset = newDragonTestAsset
            this.dragonBone_json.dragonAtlasAsset = newDragonTestAtlasAsset
            this.dragonBone_json.armatureName = 'armatureName';
            this.dragonBone_json.playAnimation('stand', 0);
        });
        //加载二进制
        this.swordsManUrlInfo = { url: "dragonbones/sword-man/SwordsMan", assetType: "DragonBonesAsset", ext: "dbbin" };
        extAssetMgr.load(this.swordsManUrlInfo, (err, items) => {
            const [dragonAsset, dragonAtlasAsset] = extAssetMgr.get(this.swordsManUrlInfo);
            this.dragonBone_bin.dragonAsset = dragonAsset
            this.dragonBone_bin.dragonAtlasAsset = dragonAtlasAsset;
            this.dragonBone_bin.armatureName = 'Swordsman-NestArmature';
            this.dragonBone_bin.playAnimation('walk', 0);
        })
    }
    releaseDragonebones() {
        aswallow.extAssetMgr.release([
            this.swordsManUrlInfo
            , this.newDragonTestAtlasResUrlInfo
            , this.newDragonTestUrlInfo
            , this.newDragonTestTexUrl]);
    }
    onDestroy() {
        this.releaseDragonebones();
    }
    // update (dt) {}
}
