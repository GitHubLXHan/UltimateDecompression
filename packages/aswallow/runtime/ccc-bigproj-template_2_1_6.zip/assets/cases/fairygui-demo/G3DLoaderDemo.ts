const { ccclass, property } = cc._decorator;

@ccclass
export default class BagDemo extends cc.Component {
    private _view: fgui.GComponent;
    private _gLoader3D_dragonbones: fgui.GLoader3D;
    private _gLoader3D_spines: fgui.GLoader3D;
    onLoad() {
        fgui.GRoot.create();
        fgui.UIPackage.loadPackage("fgui-res/G3DLoaderTest", this.onUILoaded.bind(this));
    }

    onUILoaded() {
        this._view = new fgui.GComponent();
        this._view.makeFullScreen();
        fgui.GRoot.inst.addChild(this._view);


        this._gLoader3D_dragonbones = new fgui.GLoader3D();

        this._view.addChild(this._gLoader3D_dragonbones);

        this._gLoader3D_dragonbones.url = "ui://G3DLoaderTest/mecha_1502b_ske";
        this._gLoader3D_dragonbones.loop = true;
        this._gLoader3D_dragonbones.skinName = "mecha_1502b";

        this._gLoader3D_dragonbones.animationName = "idle";

        this._gLoader3D_spines = new fgui.GLoader3D();
        this._gLoader3D_spines.setPosition(200, 100);
        this._view.addChild(this._gLoader3D_spines);
        this._gLoader3D_spines.url = "ui://G3DLoaderTest/raptor-pro";
        this._gLoader3D_spines.animationName = "walk";
        this._gLoader3D_spines.loop = true;
        this._gLoader3D_spines.scaleX = 0.5;
        this._gLoader3D_spines.scaleY = 0.5;
    }

    onDestroy() {
        fgui.UIPackage.removePackage("G3DLoaderTest");
    }
}