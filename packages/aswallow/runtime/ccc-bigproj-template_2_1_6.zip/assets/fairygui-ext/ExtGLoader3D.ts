fgui.GLoader3D.prototype["onChangeDragonBones"] = function () {
    if (!(this._content instanceof dragonBones.ArmatureDisplay))
        return;
    if (this._skinName) {
        this._content.armatureName = this._skinName;
    }
    if (this._animationName) {
        if (this._playing)
            this._content.playAnimation(this._animationName, this._loop ? 0 : 1);
        else
            this._content.armature().animation.gotoAndStopByFrame(this._animationName, this._frame);
    }
    else
        this._content.armature().animation.reset();
}