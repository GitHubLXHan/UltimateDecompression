const extLoadCache = {};
fgui.GLoader.prototype["loadExternal"] = function () {
    let url = this.url;

    let callback = (err, asset) => {
        //因为是异步返回的，而这时可能url已经被改变，所以不能直接用返回的结果

        if (this["_url"] != url || !cc.isValid(this._node))
            return;

        if (err)
            console.warn(err);
        if (asset instanceof cc.SpriteFrame) {
            this.onExternalLoadSuccess(asset);
            // extLoadCache[url] = asset;
        }
        else if (asset instanceof cc.Texture2D) {
            // extLoadCache[url] = new cc.SpriteFrame(asset);
            // this.onExternalLoadSuccess(extLoadCache[url]);
            // asset.addRef();
            this.onExternalLoadSuccess(new cc.SpriteFrame(asset));
        }

    };
    const _url = this["_url"];
    if (fgui.ToolSet.startsWith(_url, "http://")
        || fgui.ToolSet.startsWith(_url, "https://")
        || fgui.ToolSet.startsWith(_url, '/'))
        cc.assetManager.loadRemote(_url, callback);
    else if (cc.path.extname(_url) === "")
        cc.resources.load(_url, cc.Asset, callback);
    else if (extLoadCache[url]) {
        // this.onExternalLoadSuccess(extLoadCache[url]);
    } else {
        aswallow.extAssetMgr.load(_url, callback);
    }

}