const childProgress = require("child_process");

const child = childProgress.exec('D:\\programs\\CocosDashboard\\resources\\.editors\\Creator\\2.4.4\\CocosCreator.exe --path E:\\CocosSpace\\ccc-bigproj-template\\other-proj --compile "platform=web-mobile"',(err)=>{
    console.log("出错了");
    console.log(err);
})

// child.stdin.pipe(process.stdin);
// child.stdout.pipe(process.stdout);
// child.stderr.pipe(process.stderr);

