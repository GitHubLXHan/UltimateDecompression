
const CC_INTERNAL_BUNDLE_NAMES = ["main", "resources", "internal"];
const pluginLogTitle = "[ASWALLOW]";
// 接口在packages/aswallow/aswallow.d.ts
/**
 * @type {import("aswallow").IBuildScript} 
 */
const buildScript = {
    onBuildStart: (options, cb, toolOpt) => {
        Editor.log(`${pluginLogTitle} 构建结束后，复制外部资源`);
        cb();
    },
    onBeforeBuildFinish: async (options, cb, toolOpt) => {
        let extResTargetPath;
        const path = toolOpt.path;
        const assetDestPath = path.join(options.dest, "assets");
        const remoteDestPath = path.join(options.dest, "remote");
        Editor.log(`平台类型:${options.platform}`);
        Editor.log(`具体平台:${options.actualPlatform}`);
        const { buildConfig, aswallowConfig } = toolOpt.configs;
        let buildToRemote = buildConfig.extResPlatformBuildSetting ? (buildConfig.extResPlatformBuildSetting[options.platform] || buildConfig.extResPlatformBuildSetting[options.platform] === undefined) : true;
        let extResDestPath = buildToRemote ? remoteDestPath : assetDestPath;
        if (options.platform === "android" || options.platform === "ios") {
            extResTargetPath = path.join(extResDestPath, aswallowConfig.externalResPath);
        }
        else if ((options.platform === "mini-game" || options.platform === "runtime")) {
            extResTargetPath = path.join(remoteDestPath, aswallowConfig.externalResPath);
        }
        else {
            extResTargetPath = path.join(options.dest, aswallowConfig.externalResPath);
        }
        const versionFilePath = path.join(extResTargetPath, "version.json");
        try {
            if (toolOpt.fs.existsSync(extResTargetPath)) {
                Editor.log(`${pluginLogTitle} 开始删除目标目录下的外部资源:${extResTargetPath}`);
                toolOpt.fs.removeSync(extResTargetPath);
            }
        }
        catch (error) {
            Editor.error(`${pluginLogTitle} 删除旧的外部资源出错`);
            Editor.error(error);
            cb();
            return;
        }
        try {
            Editor.log(`${pluginLogTitle} 开始复制外部资源:${toolOpt.externalResPath}到${extResTargetPath}`);
            toolOpt.fs.copySync(toolOpt.externalResPath, extResTargetPath);
            Editor.log(`${pluginLogTitle} 复制外部资源完成:${extResTargetPath}`);
            if (options.md5Cache) {
                const versionObj = toolOpt.utils.getExtResVersion(extResTargetPath);
                toolOpt.fs.writeFileSync(versionFilePath, JSON.stringify(versionObj), { encoding: "utf-8" });
            }
        }
        catch (error) {
            Editor.error(`${pluginLogTitle}复制外部资源出错`);
            Editor.error(error);
            cb();
            return;
        }
        cb();
    },
    onBuildFinished: (options, cb, toolOpt) => {
        const path = toolOpt.path;
        const assetDestPath = path.join(options.dest, "assets");
        Editor.log(`${pluginLogTitle} 构建子项目`);
        const { buildConfig } = toolOpt.configs;
        const curProjBundleNames = options.bundles.map((value) => {
            return value.name;
        });
        const mainSettingsBuilderJsonPath = toolOpt.resolveToProjectPath("settings/builder.json");
        const mainSettingsBuilderJsonObj = JSON.parse(toolOpt.fs.readFileSync(mainSettingsBuilderJsonPath, "utf-8"));
        const mainLocalBuilderJsonPath = toolOpt.resolveToProjectPath("local/builder.json");
        const mainLocalBuilderJsonObj = JSON.parse(toolOpt.fs.readFileSync(mainLocalBuilderJsonPath, "utf-8"));
        const subProjPaths = buildConfig.subProjConfig ? Object.keys(buildConfig.subProjConfig) : [];
        if (subProjPaths && subProjPaths.length) {
            let publishedCount = 0;
            const publishTotalCount = subProjPaths.length;
            const publishFailSubProjPaths = [];
            const copyEndCallback = async (hasError) => {
                publishedCount++;
                if (publishedCount >= publishTotalCount) {
                    Editor.log(`${pluginLogTitle}:全部子项目构建完成`);
                    Editor.log(`${pluginLogTitle}:更新版本号信息`);
                    Editor.log(`${pluginLogTitle} 开始处理setting.js中的bundle版本号`);
                    let ccSettings = toolOpt.utils.getCCSettingsInfo(options.dest, options.debug, options.encryptJs && options.xxteaKey, options.zipCompressJs);
                    if (!ccSettings) {
                        Editor.error(`${pluginLogTitle} settings.js读取不到，构建出错，结束`);
                        cb();
                        return;
                    }
                    Editor.log(`${pluginLogTitle} 获取版本号`);
                    ccSettings.bundleVers = await toolOpt.utils.getBundleVers(assetDestPath, true);
                    if (options.platform !== "web-desktop" && options.platform !== "web-mobile") {
                        Editor.log(`${pluginLogTitle} 获取remote版本号`);
                        const remoteBundleVers = await toolOpt.utils.getBundleVers(path.join(options.dest, "remote"), true);
                        const remoteBundleNames = Object.keys(remoteBundleVers);
                        if (remoteBundleNames.length > 0) {
                            ccSettings.bundleVers = Object.assign(ccSettings.bundleVers, remoteBundleVers);
                            ccSettings.remoteBundles = remoteBundleNames;
                        }
                    }
                    const bundleNames = Object.keys(ccSettings.bundleVers);
                    for (let key in bundleNames) {
                        if (ccSettings.bundleVers[bundleNames[key]] === undefined) {
                            delete ccSettings.bundleVers[bundleNames[key]];
                        }
                    }
                    Editor.log(`${pluginLogTitle} 保存settings.js`);
                    const settingJSFilePath = toolOpt.utils.saveCCSettings(options.dest, ccSettings, options.debug, options.md5Cache && options.platform !== "mini-game", options.encryptJs && options.xxteaKey, options.zipCompressJs);
                    Editor.log(`${pluginLogTitle} setting.js中的bundle版本号处理完成`, ccSettings.bundleVers);
                    const withJsRegexp1 = /"*\/settings\..*\.js"/gm;
                    const withJsRegexp2 = /'*\/settings\..*\.js'/gm;
                    switch (options.platform) {
                        case "android":
                        case "ios":
                            Editor.log(`${pluginLogTitle} 重写对settings.js的引用`);
                            const mainJsFilePath = path.join(options.dest, "main.js");
                            let mainJsStr = toolOpt.fs.readFileSync(mainJsFilePath, "utf-8");
                            mainJsStr = mainJsStr.replace(withJsRegexp1, `/${path.basename(settingJSFilePath)}"`);
                            mainJsStr = mainJsStr.replace(withJsRegexp2, `/${path.basename(settingJSFilePath)}'`);
                            toolOpt.fs.writeFileSync(mainJsFilePath, mainJsStr, { encoding: "utf-8" });
                            break;
                        case "web-desktop":
                        case "web-mobile":
                            Editor.log(`${pluginLogTitle} 重写对settings.js的引用`);
                            const indexFilePath = path.join(options.dest, "index.html");
                            let indexStr = toolOpt.fs.readFileSync(indexFilePath, "utf-8");
                            indexStr = indexStr.replace(withJsRegexp1, `/${path.basename(settingJSFilePath)}"`);
                            indexStr = indexStr.replace(withJsRegexp2, `/${path.basename(settingJSFilePath)}'`);
                            toolOpt.fs.writeFileSync(indexFilePath, indexStr, { encoding: "utf-8" });
                            break;
                    }
                    if (options.platform === "mini-game") {
                        Editor.log(`${pluginLogTitle} 重写ccRequire的moduleMap`);
                        let addModuleIndexStr = "";
                        const ccRequireJsFilePath = path.join(options.dest, "ccRequire.js");
                        let ccRequireStr = toolOpt.fs.readFileSync(ccRequireJsFilePath, "utf-8");
                        for (let key in bundleNames) {
                            let bundleName = bundleNames[key];
                            if (!CC_INTERNAL_BUNDLE_NAMES.includes(bundleName)) {
                                let modulePath;
                                if (ccSettings.remoteBundles.includes(bundleName)) {
                                    modulePath = `src/scripts/${bundleName}/index.js`;
                                }
                                else {
                                    modulePath = `assets/${bundleName}/index.js`;
                                }
                                if (!ccRequireStr.includes(`'${modulePath}'`)) {
                                    addModuleIndexStr += `'${modulePath}' () { return require('${modulePath}') },\n`;
                                }
                            }
                        }
                        if (addModuleIndexStr !== "") {
                            addModuleIndexStr += "// tail";
                            ccRequireStr = ccRequireStr.replace(/\/\/ tail/gm, addModuleIndexStr);
                            toolOpt.fs.writeFileSync(ccRequireJsFilePath, ccRequireStr, { "encoding": "utf-8" });
                            Editor.log(`${pluginLogTitle} 重写ccRequire的moduleMap完成`);
                        }
                        else {
                            Editor.log(`${pluginLogTitle} 不需要重写ccRequire的moduleMap`);
                        }
                    }
                }
                if (hasError) {
                    Editor.error(`${pluginLogTitle} 子项目bundle复制异常，请检查日志`);
                }
                if (publishFailSubProjPaths.length) {
                    Editor.error(`${pluginLogTitle} 构建失败的子项目`, publishFailSubProjPaths);
                }
                Editor.log(`${pluginLogTitle} 构建结束`);
                cb();
            };
            const doCopy = async (projPath) => {
                Editor.log(`${pluginLogTitle} 复制${projPath}的assetBundle到：${assetDestPath}`);
                toolOpt.subProjPublishUtils.copySubProjAssetBundle({
                    subProjPath: projPath,
                    mainProjPlatformBuildPath: options.dest,
                    platform: options.platform,
                    blackBundleNames: curProjBundleNames,
                    callback: copyEndCallback
                });
            };
            if (!buildConfig.mutiProgressBuildSubProj) {
                if (buildConfig.forceBuildSubProj) {
                    const doPublish = (subProjPath) => {
                        return toolOpt.subProjPublishUtils.buildSubProj({
                            projPath: subProjPath,
                            outputBuildLog: buildConfig.outputSubProjBuildLog,
                            mainSettingsBuilderJsonObj, mainLocalBuilderJsonObj,
                            publishCallback: (err) => {
                                if (!err) {
                                    doCopy(subProjPath);
                                }
                                else {
                                    publishFailSubProjPaths.push(subProjPath);
                                    copyEndCallback(false);
                                }
                                let publishSubProjPath = subProjPaths.pop();
                                if (publishSubProjPath) {
                                    publishSubProjPath = toolOpt.utils.resolveToProjectPath(publishSubProjPath);
                                    doPublish(publishSubProjPath);
                                }
                            }
                        });
                    };
                    let subProjPath = subProjPaths.pop();
                    subProjPath = toolOpt.utils.resolveToProjectPath(subProjPath);
                    doPublish(subProjPath);
                }
                else {
                    Editor.log(`${pluginLogTitle} 不强制发布子项目，报错请先发布子项目，或者修改配置forceBuildSubProj，强制发布子项目`);
                    for (let i = 0; i < subProjPaths.length; i++) {
                        doCopy(toolOpt.utils.resolveToProjectPath(subProjPaths[i]));
                    }
                }
            }
            else {
                for (let i = 0; i < subProjPaths.length; i++) {
                    const subProjPath = subProjPaths[i];
                    toolOpt.subProjPublishUtils.buildSubProj({
                        projPath: subProjPath,
                        outputBuildLog: buildConfig.outputSubProjBuildLog,
                        mainSettingsBuilderJsonObj, mainLocalBuilderJsonObj,
                        publishCallback: (err) => {
                            if (!err) {
                                doCopy(subProjPath);
                            }
                        }
                    });
                }
            }
        }
        else {
            Editor.log(` 没有子项目需要发布`);
            Editor.log(`${pluginLogTitle}构建结束`);
            cb();
        }
    }
}
// module.exports = buildScript;